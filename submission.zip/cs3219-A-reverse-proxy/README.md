# CS3219 Task A: Reverse Proxy

## Setup
* Clone or download the repo and cd into the project directory
* Build the images by running docker-compose build
* To start the server, run docker-compose up
* Access the server at http://localhost:80
* To stop the server, run docker-compose down
